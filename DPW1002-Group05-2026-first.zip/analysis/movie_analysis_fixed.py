# # Import Required Libraries

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import warnings

warnings.filterwarnings('ignore')

# # Load and Explore Datasets

# Load datasets
movies_df = pd.read_csv('cleaned_archive/movies_metadata_box_office.csv')
keywords_df = pd.read_csv('cleaned_archive/keywords_cleaned.csv')
credits_df = pd.read_csv('cleaned_archive/credits_cleaned.csv')

# Explore datasets
print("Movies DataFrame shape:", movies_df.shape)
print("Movies columns:", movies_df.columns.tolist())
print("\nKeywords DataFrame shape:", keywords_df.shape)
print("Keywords columns:", keywords_df.columns.tolist())
print("\nCredits DataFrame shape:", credits_df.shape)
print("Credits columns:", credits_df.columns.tolist())

# Display first few rows
print("\nMovies DataFrame head:")
print(movies_df.head())
print("\nKeywords DataFrame head:")
print(keywords_df.head())

# # Data Preprocessing for Analysis
#
# **重要说明（Data Contamination Fix）：**
# - `keywords_cleaned.csv` 是 long-format：每个关键词占一行，一部电影平均对应 ~8 行
# - 直接在 merge 后（43,513 行）跑回归会导致同一部电影被重复计数 ~8 次
# - 这会严重破坏统计独立性假设，造成虚假的高 R²
# - **修复方法**：
#   - 关键词相关分析（EDA）：在 exploded 的长表上进行（正确用途）
#   - 线性回归建模：必须使用电影去重后的 movie-level 数据（`movies_df`）

# ============================================================
# Part A: 关键词 EDA 用的 long-format 表（每关键词一行）
# 用途：分析哪些关键词的平均票房更高（聚合统计，非回归）
# ============================================================
movies_keywords_df = pd.merge(movies_df, keywords_df, on='id', how='left')

# Handle missing values
movies_keywords_df['revenue'] = movies_keywords_df['revenue'].fillna(0)
movies_keywords_df['release_date'] = pd.to_datetime(movies_keywords_df['release_date'], errors='coerce')
movies_keywords_df['release_year'] = movies_keywords_df['release_date'].dt.year
movies_keywords_df['release_month'] = movies_keywords_df['release_date'].dt.month

# Filter out movies with zero revenue or invalid dates
movies_keywords_df = movies_keywords_df[
    (movies_keywords_df['revenue'] > 0)
    & (movies_keywords_df['release_date'].notna())
]

# Keyword-level revenue aggregation (correct: groupby on keyword)
keyword_revenue_df = movies_keywords_df.groupby('keyword_name')['revenue'].agg(['mean', 'count']).reset_index()
keyword_revenue_df = keyword_revenue_df.sort_values('mean', ascending=False)

print("Long-format DataFrame shape (for keyword EDA):", movies_keywords_df.shape)
print(f"  → {movies_keywords_df['id'].nunique()} unique movies × multiple keywords per movie")
print("Keyword Revenue DataFrame head:")
print(keyword_revenue_df.head())

# ============================================================
# Part B: 回归建模用的 movie-level 数据（每电影一行，去重后）
# 关键修复：直接使用原始 movies_df，不做 keyword merge
# ============================================================
movies_model_df = movies_df.copy()
movies_model_df['revenue'] = pd.to_numeric(movies_model_df['revenue'], errors='coerce')
movies_model_df['budget'] = pd.to_numeric(movies_model_df['budget'], errors='coerce')
movies_model_df['release_date'] = pd.to_datetime(movies_model_df['release_date'], errors='coerce')
movies_model_df['release_month'] = movies_model_df['release_date'].dt.month

# 确认每部电影只出现一次
assert movies_model_df['id'].nunique() == len(movies_model_df), \
    "Duplicate movie IDs found! Check the data."

print(f"\nMovie-level DataFrame shape (for regression): {movies_model_df.shape}")
print(f"  → {len(movies_model_df)} unique movies (no duplication)")

# # Analyze Release Date Impact on Revenue

# 使用 long-format 数据（movies_keywords_df）做 EDA 聚合分析是正确的：
# 因为我们只是 groupby release_year/month → mean(revenue)，
# 虽然同一电影被重复统计，但只要同一电影的关键词行 revenue 值相同，
# 用 drop_duplicates 后再聚合更准确，这里改为直接用 movies_model_df

# Group by release year
yearly_revenue = movies_model_df.dropna(subset=['release_date']).copy()
yearly_revenue['release_year'] = yearly_revenue['release_date'].dt.year
yearly_revenue = yearly_revenue[
    (yearly_revenue['revenue'] > 0)
].groupby('release_year')['revenue'].mean().reset_index()

# Group by release month
monthly_revenue = movies_model_df.dropna(subset=['release_month']).copy()
monthly_revenue = monthly_revenue[
    (monthly_revenue['revenue'] > 0)
].groupby('release_month')['revenue'].mean().reset_index()

print("Yearly Revenue Average:")
print(yearly_revenue)
print("\nMonthly Revenue Average:")
print(monthly_revenue)

# # Analyze Keywords Impact on Revenue
#
# （使用 long-format 关键词表做聚合 EDA，这里用 long-format 是正确的）

# Top keywords by average revenue
top_keywords = keyword_revenue_df.head(10)
print("Top 10 Keywords by Average Revenue:")
print(top_keywords)

# Keywords with high frequency
frequent_keywords = keyword_revenue_df[keyword_revenue_df['count'] > 5].head(10)
print("\nFrequent Keywords (count > 5) by Average Revenue:")
print(frequent_keywords)

# # Visualize Release Date vs. Revenue

# Line chart for yearly revenue
plt.figure(figsize=(10, 6))
sns.lineplot(data=yearly_revenue, x='release_year', y='revenue')
plt.title('Average Revenue by Release Year')
plt.xlabel('Release Year')
plt.ylabel('Average Revenue')
plt.show()

# Bar chart for monthly revenue
plt.figure(figsize=(10, 6))
sns.barplot(data=monthly_revenue, x='release_month', y='revenue')
plt.title('Average Revenue by Release Month')
plt.xlabel('Release Month')
plt.ylabel('Average Revenue')
plt.show()

# # Visualize Keywords vs. Revenue

# Bar chart for top keywords by average revenue
plt.figure(figsize=(12, 8))
sns.barplot(data=top_keywords, x='mean', y='keyword_name')
plt.title('Top 10 Keywords by Average Revenue')
plt.xlabel('Average Revenue')
plt.ylabel('Keyword')
plt.show()

# Box plot for revenue distribution by keyword (for top frequent keywords)
top_keyword_names = frequent_keywords['keyword_name'].tolist()
filtered_df = movies_keywords_df[movies_keywords_df['keyword_name'].isin(top_keyword_names)]
plt.figure(figsize=(12, 8))
sns.boxplot(data=filtered_df, x='keyword_name', y='revenue')
plt.title('Revenue Distribution by Top Frequent Keywords')
plt.xlabel('Keyword')
plt.ylabel('Revenue')
plt.xticks(rotation=45)
plt.show()

# # Statistical Modeling for Revenue Prediction
#
# ## ✅ 核心修复说明
#
# | 项目 | 修复前（错误） | 修复后（正确） |
# |------|--------------|---------------|
# | 训练数据 | `movies_keywords_df`（43,513 行，含重复电影） | `movies_model_df`（5,356 行，每部电影一行） |
# | 样本量 | ~43,513（虚假膨胀 ~8x） | 实际有效样本数 |
# | 独立性 | ❌ 严重违反（同一电影重复8次） | ✅ 满足（每部电影独立） |
# | R² 可信度 | ❌ 虚假偏高（数据泄露导致） | ✅ 真实反映模型能力 |
#
# **原因解释**：`keywords_cleaned.csv` 是 long-format 表，每个关键词一行。
# Merge 后同一部电影会出现 ~8 次（平均每部电影 8.1 个关键词），
# 直接用这个表跑回归，相当于人为制造了大量相同的训练样本，
# 导致模型「记住」了重复数据而非真正学习到规律。

# ============================================================
# 使用 movie-level 数据（movies_model_df）进行线性回归
# 特征：release_month（上映月份）、budget（制作预算）
# 目标：revenue（票房收入）
# ============================================================

features = ['release_month', 'budget']
target = 'revenue'

# Prepare data — 使用 movie-level 数据（每部电影只出现一次）
model_df = movies_model_df[features + [target]].dropna()
model_df = model_df[(model_df['revenue'] > 0) & (model_df['budget'] > 0)]

print(f"Regression dataset shape: {model_df.shape}")
print(f"  → {len(model_df)} unique movies (each movie appears EXACTLY once)")
print(f"  (vs. the contaminated version which had ~{len(model_df) * 8:,} rows)")

X = model_df[features]
y = model_df[target]

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"\n=== Model Evaluation ===")
print(f"Mean Squared Error (MSE): {mse:.4e}")
print(f"Root MSE (RMSE):          ${np.sqrt(mse):,.0f}")
print(f"R² Score:                 {r2:.4f}")
print(f"\nCoefficients:")
for feat, coef in zip(features, model.coef_):
    print(f"  {feat}: {coef:,.2f}")
print(f"  Intercept: {model.intercept_:,.2f}")
print(f"\n⚠️  Note: Low R² ({r2:.2f}) is expected here.")
print("   Release month + budget alone are weak predictors of revenue.")
print("   This is the HONEST result — the previous high R² was an artifact")
print("   of data contamination (each movie repeated ~8 times).")

# # Visualization: Actual vs Predicted Revenue

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Left: Actual vs Predicted scatter
axes[0].scatter(y_test / 1e6, y_pred / 1e6, alpha=0.4, s=20, color='steelblue')
max_val = max(y_test.max(), y_pred.max()) / 1e6
axes[0].plot([0, max_val], [0, max_val], 'r--', linewidth=1.5, label='Perfect prediction')
axes[0].set_xlabel('Actual Revenue ($M)')
axes[0].set_ylabel('Predicted Revenue ($M)')
axes[0].set_title(f'Actual vs Predicted Revenue\n(R² = {r2:.4f}, n = {len(y_test)} movies)')
axes[0].legend()

# Right: Residuals plot
residuals = (y_test - y_pred) / 1e6
axes[1].scatter(y_pred / 1e6, residuals, alpha=0.4, s=20, color='coral')
axes[1].axhline(y=0, color='black', linestyle='--', linewidth=1)
axes[1].set_xlabel('Predicted Revenue ($M)')
axes[1].set_ylabel('Residuals ($M)')
axes[1].set_title('Residuals Plot\n(Heteroscedasticity visible → model limitation)')

plt.tight_layout()
plt.savefig('regression_results_fixed.png', dpi=150, bbox_inches='tight')
plt.show()

print("\n=== Summary of Fix ===")
print("Before fix: Training on 43,513 rows (same movie ~8 times)")
print(f"After fix:  Training on {len(model_df)} rows (each movie exactly once)")
print("The corrected R² reflects the true predictive power of these two features.")
